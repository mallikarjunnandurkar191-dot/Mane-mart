const orderButtons = document.querySelectorAll(".product button");

orderButtons.forEach(function(button) {
    button.addEventListener("click", function() {
        const product = this.parentElement.querySelector("h3").innerText;
        const price = this.parentElement.querySelector(".price").innerText;

        alert(
            "Mane Mart\n\n" +
            "Product: " + product + "\n" +
            "Price: " + price + "\n\n" +
            "Order selected successfully!"
        );
    });
});

const whatsappButton = document.getElementById("whatsappBtn");

whatsappButton.addEventListener("click", function() {
    const phoneNumber = "919740117568";
    const message = "Hello Mane Mart! I want to place an order.";

    const whatsappURL =
        "https://wa.me/" + phoneNumber +
        "?text=" + encodeURIComponent(message);

    window.location.href = whatsappURL;
});
